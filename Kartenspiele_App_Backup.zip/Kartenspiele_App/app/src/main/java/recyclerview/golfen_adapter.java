package recyclerview;

import android.content.Context;
import android.content.DialogInterface;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.example.nachtaktiverhalbaffe.kartenspiele.Golfen;
import com.example.nachtaktiverhalbaffe.kartenspiele.R;

import java.util.ArrayList;
import java.util.List;

import Database.Golf_database;
import Database.Golfen_Partie;
import Database.Golfen_Spieler;

import static java.lang.Integer.valueOf;

public class golfen_adapter extends RecyclerView.Adapter <golfen_adapter.Golfen_ListViewHolder> {
    private Golf_database golfen_database = null;
    private Context mContext;
    View.OnClickListener itemClickListener = null;
    List<Golfen_Spieler> golf_spieler = new ArrayList<>();
    Golfen_Partie golfen_partien;
    public static int f ;

    public golfen_adapter(FragmentActivity activity, Golf_database golfen_database, View.OnClickListener itemClickListener) {
      mContext=activity.getApplicationContext();
      this.golfen_database=golfen_database;
      this.itemClickListener= itemClickListener;

    }

    static class Golfen_ListViewHolder extends RecyclerView.ViewHolder {
        static TextView titel, spieler_1, spieler_2, spieler_3, spieler_4, spieler_5, spieler_6, spieler_7, spieler_8,

                score1, score2, score3, score4, score5, score6, score7, score8;
        static FloatingActionButton Edit;
        static TableLayout Table;
        static TableRow Namen, Score;

        Golfen_ListViewHolder(View itemView, View.OnClickListener itemClickListener) {                                                     //Variablen fÃ¼r cards setzen
            super(itemView);
            f=getAdapterPosition();
            titel = itemView.findViewById((R.id.golfen_titel));
            spieler_1 = itemView.findViewById((R.id.golfen_spieler1));
            spieler_2 = itemView.findViewById((R.id.golfen_spieler2));
            spieler_3 = itemView.findViewById((R.id.golfen_spieler3));
            spieler_4 = itemView.findViewById((R.id.golfen_spieler4));
            spieler_5 = itemView.findViewById((R.id.golfen_spieler5));
            spieler_6 = itemView.findViewById((R.id.golfen_spieler6));
            spieler_7 = itemView.findViewById((R.id.golfen_spieler7));
            spieler_8 = itemView.findViewById((R.id.golfen_spieler8));
            /*punkte1 = itemView.findViewById(R.id.punkte1);
            punkte2 = itemView.findViewById(R.id.punkte2);
            punkte3 = itemView.findViewById(R.id.punkte3);
            punkte4 = itemView.findViewById(R.id.punkte4);
            punkte5 = itemView.findViewById(R.id.punkte5);
            punkte6 = itemView.findViewById(R.id.punkte6);
            punkte7 = itemView.findViewById(R.id.punkte7);
            punkte8 = itemView.findViewById(R.id.punkte8);*/
            score1 = itemView.findViewById(R.id.score1);
            score2 = itemView.findViewById(R.id.score2);
            score3 = itemView.findViewById(R.id.score3);
            score4 = itemView.findViewById(R.id.score4);
            score5 = itemView.findViewById(R.id.score5);
            score6 = itemView.findViewById(R.id.score6);
            score7 = itemView.findViewById(R.id.score7);
            score8 = itemView.findViewById(R.id.score8);

            Edit = itemView.findViewById(R.id.golfen_card_edit);
            Table = itemView.findViewById(R.id.golfen_table);
            Namen = itemView.findViewById(R.id.golfen_card_name);
            Score = itemView.findViewById(R.id.score);
            itemView.setClickable(false);
            Edit.setOnClickListener(itemClickListener);

        }
    }

    @Override
    public golfen_adapter.Golfen_ListViewHolder onCreateViewHolder(ViewGroup parent, final int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.golfen_card, null);
        Golfen_ListViewHolder holder = new Golfen_ListViewHolder(v, itemClickListener);
        f= viewType;
        return holder;
    }

    @Override
    public void onBindViewHolder(golfen_adapter.Golfen_ListViewHolder holder, int position) {
        final Golfen_Partie golfen_partie = golfen_database.golfen_spieler_dao().getAllGolfen_Partien().get(position);
        List<Golfen_Spieler> list = golfen_partie.getGolfen_spieler();
        TableLayout table = Golfen_ListViewHolder.Table;
        Golfen_ListViewHolder.titel.setText(golfen_partie.getPartiebezeichnung());

        for (int i = 0; i <list.size(); ++i) {

            if (i == 0) {

                for (int j = 0; j < 8; j++) {
                    switch (j) {
                        case 0:
                            Golfen_ListViewHolder.spieler_1.setText(list.get(j).getName());
                            break;
                        case 1:
                            Golfen_ListViewHolder.spieler_2.setText(list.get(j).getName());
                            break;
                        case 2:
                            Golfen_ListViewHolder.spieler_3.setText(list.get(j).getName());
                            break;
                        case 3:
                            Golfen_ListViewHolder.spieler_4.setText(list.get(j).getName());
                            break;
                        case 4:
                            Golfen_ListViewHolder.spieler_5.setText(list.get(j).getName());
                            break;
                        case 5:
                            Golfen_ListViewHolder.spieler_6.setText(list.get(j).getName());
                            break;
                        case 6:
                            Golfen_ListViewHolder.spieler_7.setText(list.get(j).getName());
                            break;
                        case 7:
                            Golfen_ListViewHolder.spieler_8.setText(list.get(j).getName());
                            break;
                    }
                }


                if (i<list.size()) {


                    for (int j = 0; j < 8; j++) {
                        TableRow row = new TableRow(mContext);
                        row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT));
                        TextView punkte1 = new TextView(mContext);
                        TextView punkte2 = new TextView(mContext);
                        TextView punkte3 = new TextView(mContext);
                        TextView punkte4 = new TextView(mContext);
                        TextView punkte5 = new TextView(mContext);
                        TextView punkte6 = new TextView(mContext);
                        TextView punkte7 = new TextView(mContext);
                        TextView punkte8 = new TextView(mContext);
                        row.addView(punkte1);
                        row.addView(punkte2);
                        row.addView(punkte3);
                        row.addView(punkte4);
                        row.addView(punkte5);
                        row.addView(punkte6);
                        row.addView(punkte7);
                        row.addView(punkte8);
                        table.addView(row);
                        if(list.get(i).getPunkte()!= null) {
                            switch (j) {
                                case 0:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte1.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte1.setText("");
                                    break;
                                case 1:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte2.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte2.setText("");
                                    break;
                                case 2:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte3.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte3.setText("");
                                    break;
                                case 3:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte4.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte4.setText("");
                                    break;
                                case 4:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte5.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte5.setText("");
                                    break;
                                case 5:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte6.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte6.setText("");
                                    break;
                                case 6:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte7.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte7.setText("");
                                    break;
                                case 7:
                                    if(list.get(i).getPunkte().get(j)!=null){
                                    punkte8.setText(String.valueOf(list.get(i).getPunkte().get(j)));}
                                    else punkte8.setText("");
                                    break;
                            }
                        }
                        }
                } else {
                    for (int s = 0; s < 8; s++) {
                        switch (s) {
                            case 0:
                                Golfen_ListViewHolder.score1.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                            case 1:
                                Golfen_ListViewHolder.score2.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                            case 2:
                                Golfen_ListViewHolder.score3.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                            case 3:
                                Golfen_ListViewHolder.score4.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                            case 4:
                                Golfen_ListViewHolder.score5.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                            case 5:
                                Golfen_ListViewHolder.score6.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                            case 6:
                                Golfen_ListViewHolder.score7.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                            case 7:
                                Golfen_ListViewHolder.score8.setText(String.valueOf(list.get(s).getSumme()));
                                break;
                        }
                    }
                }
            }
        }
    }


    @Override
    public int getItemCount() {
        return golfen_database.golfen_spieler_dao().getAllGolfen_Partien().size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }




}