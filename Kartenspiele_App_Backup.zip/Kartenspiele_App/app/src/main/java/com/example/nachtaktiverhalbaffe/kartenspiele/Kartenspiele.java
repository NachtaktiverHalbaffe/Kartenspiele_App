package com.example.nachtaktiverhalbaffe.kartenspiele;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/**
 * Created by NachtaktiverHalbaffe on 28.11.2017.
 */

public class Kartenspiele extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {   //Fragment Preambel
        View rootView = inflater.inflate(R.layout.kartenspiele, container, false);
        TextView text= rootView.findViewById(R.id.Willkommenstext);
        text.setText("Wilkommen zur Kartenspiele-App! Falls du sie zum ersten mal benutzt, dann solltest du dir das hier durchlesen. Ansonsten weißt du ja, wie man sie benutzt ;)"+"\n\n"+"Hier werden Kartenspiele erklärt, die man mit jeden Poker- oder Skatdeck spielen kann. Wenn man auf den Knopf drückt, dann wird das jeweilge Spiel sowie ggf. wie man den Punktestand in der App notiert erklärt. Also habt Spaß und möge der Bessere gewinnen :D"+"\n\n"+
                "Funfacts/Nutzloses Wissen:\n"+
                "-In einer Kneipe macht das spielen mehr Spaß\n"+  "" +
                "-Diese App wurde entwickelt, um den Verbrauch von Servietten zu minimieren\n" +
                "-Danksagungen an meinen Studium, dass mich hierzu getrieben hat\n" +
                "-Eine Gruppe ohne Spielkarten ist wie eine Kneipe ohne Bier\n"+
                "-Reschreib- oder Grammatikfehler könnt ihr euch schänken\n"+
                "-IntelliJ ist eine bessere IDE als Eclipse (Danke für das Leid GdP)\n"+
                "-Informatiker würden sterben, wenn sie diesen Code sehen\n"+
                "-Affenpower!");

        return rootView;
    }
}
