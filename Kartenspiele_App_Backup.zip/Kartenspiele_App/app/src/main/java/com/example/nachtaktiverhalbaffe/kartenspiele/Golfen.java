package com.example.nachtaktiverhalbaffe.kartenspiele;

import android.arch.persistence.room.Room;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Database.Golfen_Partie;
import Database.Golfen_Spieler;
import Database.Golf_database;
import recyclerview.golfen_adapter;

import static java.lang.Integer.valueOf;

/**
 * Created by NachtaktiverHalbaffe on 29.11.2017.
 */

public class Golfen extends Fragment {
    public static Golf_database golfen_db;
    public List<Golfen_Spieler> golfen_spieler =new ArrayList<>();
    public golfen_adapter adapter;
    public Integer i=0, j=0;
    public List<Golfen_Spieler> golf_spieler=null;
    public Golfen_Partie golfen_partien =null;
    int f = 0;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {   //Fragment Preambel
        View rootView = inflater.inflate(R.layout.golfen, container, false);

        FloatingActionButton anl = rootView.findViewById(R.id.golfen_anleitung);
        anl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String anleitung = "Golfen\n" +
                        "\n" +
                        "Ziel: Die niedrigste Punktzahl erreichen\n\n" +
                        "Spielprinzip: Jeder hat 6 Karten vor sich liegen. Manche verdeckt manche offen. " +
                        "Reihum hat jeder eine Wahl: Entweder er nimmt die oberste Karte des Ablagestapels oder zieht vom Kartenstapel. " +
                        "Diese kann er dann mit einen seiner Karten austauschen. Die Ausgetauschte Karte kommt oben auf den Ablagestapel\n\n" +
                        "Spielablauf:\n" +
                        "1. Jeder bekommt verdeckt 6 Karten ausgeteilt. Die karten werden in einen 2x3 Raster hingelegt. Anschließend deckt der Spieler zwei Karten auf, die nebeneinander liegen müssen\n" +
                        "2. Der erste deckt die oberste Karte vom Kartenstapel auf und entscheidet, ob er sie mit einer eigenen Karte tauschen will oder nicht. Die getauschte oder aufgedeckte Karte wird offen auf den Ablagestapel abgelegt\n" +
                        "3. Der nächste hat die Wahl, die oberste Karte vom Kartenstapel oder Abagestapel aufzunehmen und analog wie in Schritt 2 mit den eigenen Karten zu tauschen. Ist der Kartenstapel leer, wird der Abagestapel gemischt und verdeckt als neuer Kartenstapel hingelegt.\n " +
                        "4. Schritt 3 wird solange wiederholt, bis ein Spieler alle eigenen Karten aufgedeckt und die restlichen Spieler die letzte Runde absolviert haben\n\n"+
                        "Wertung:\n" +
                        "Die Zahlenwerte der Karten entsprechen ihren Punkten mit Ausnahme der roten Neunen, die -2 Punkte geben. Der Bube gibt 11, die Dame 12, der König 0 und das Ass -1 Punkte. Zwei identische Karten nebeneinander heben sich gegenseitig zu null auf (auch bei Minuswerten). Hat man alle 4 Karten eines Zahlenwertes, geben diese nach der Runde zusätzlich -5 Punkte. Die Ergebnisse der Runden werden zusammengetragen und der Spieler mit den wenigsten Punkten gewinnt.";
                AlertDialog.Builder builder_kon = new AlertDialog.Builder(getActivity());
                builder_kon.setMessage(anleitung);
                AlertDialog dialog = builder_kon.create();
                dialog.show();
            }
        });
        RecyclerView mRecyclerview = rootView.findViewById(R.id.golfen_card);

        golfen_db = Room.databaseBuilder(getActivity(),Golf_database.class,"Database Golfen").allowMainThreadQueries().build();
        final LinearLayoutManager team_llm = new LinearLayoutManager(getActivity());
        mRecyclerview.setLayoutManager(team_llm);
        adapter = new golfen_adapter(getActivity(), golfen_db, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                golfen_partien=golfen_db.golfen_spieler_dao().getAllGolfen_Partien().get(golfen_adapter.f);
                golf_spieler = golfen_partien.getGolfen_spieler();
                input_punkte(0);
            }
        });
        mRecyclerview.setAdapter(adapter);

        FloatingActionButton add = rootView.findViewById(R.id.golfen_add);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new_players(0);
            }
        });
        if(i!=0){
        adapter.notifyDataSetChanged();
        mRecyclerview.setLayoutManager(team_llm);
        i=0;}
        return rootView;
    }

    void new_players(int nummer){
            if(nummer<8) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
                final EditText input = new EditText(getActivity());
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                dialogBuilder.setView(input);
                dialogBuilder.setTitle("Spieler " + (nummer+1));
                dialogBuilder.setMessage("Name des " + (nummer+1) + ". Spielers eingeben oder frei lassen");
                dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        golfen_spieler.add(new Golfen_Spieler(input.getText().toString(), null, 0));
                        j++;
                        new_players(j);
                    }
                });
                dialogBuilder.show();
            }else new_List(golfen_spieler);
    }

    void new_List(final List<Golfen_Spieler> golfen_spieler){

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        final EditText input = new EditText(getActivity());
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        dialogBuilder.setView(input);
        dialogBuilder.setTitle("Titel");
        dialogBuilder.setMessage("Name der Partie eingeben");
        dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                if(input.getText()!=null) {
                    golfen_db.golfen_spieler_dao().addGolfen_Partie(new Golfen_Partie(input.getText().toString(), golfen_spieler));
                    j=0;
                }
                else{
                    Toast toast = Toast.makeText(getActivity(), "Bitte einen gültigen Partienamen eingeben", Toast.LENGTH_LONG);
                    toast.show();
                    new_List(golfen_spieler);
                }
            }
        });
        dialogBuilder.show();
    }



    public class addListenerOnTextChange implements TextWatcher {
        private Context mContext;
        EditText mEdittextview;

        public addListenerOnTextChange(Context context, EditText edittextview) {
            super();
            this.mContext = context;
            this.mEdittextview= edittextview;
        }

        @Override
        public void afterTextChanged(Editable s) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,
                                      int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //What you want to do
        }
    }

    void input_punkte(final int nummer) {
        if(nummer <8) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
            final EditText input = new EditText(getActivity());
            input.setInputType(InputType.TYPE_CLASS_NUMBER);
            dialogBuilder.setView(input);
            dialogBuilder.setTitle(golf_spieler.get(nummer).getName());
            dialogBuilder.setMessage("Punkte von dieser Runde von "+golf_spieler.get(nummer).getName()+" eingeben");
            dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    int sum = 0;
                    List<Integer> punkte ;
                    if(golf_spieler.get(nummer).getPunkte()!=null) {
                        punkte = golf_spieler.get(nummer).getPunkte();
                    }else {punkte = new ArrayList<>();}
                    if (!input.toString().equals("")) {
                        punkte.add(Integer.valueOf(input.getText().toString()));
                        for (int j = 0; j < punkte.size(); j++) {
                            sum = sum + punkte.get(j);
                        }
                        golfen_spieler.add(new Golfen_Spieler(golf_spieler.get(nummer).getName(), punkte, sum));
                        f=nummer+1;
                        input_punkte(f);
                    } else{
                        Toast toast = Toast.makeText(getActivity(), "Bitte Punkte eingeben oder 0 eintragen, falls der Spieler die Runde ausgesetzt hat", Toast.LENGTH_LONG);
                        toast.show();
                    }
                }
            });
            dialogBuilder.show();
        }
        else {
            golfen_db.golfen_spieler_dao().updateGolfen_Partie(new Golfen_Partie(golfen_partien.getPartiebezeichnung(),golfen_spieler));
            golfen_db = Room.databaseBuilder(getActivity(),Golf_database.class,"Database Golfen").allowMainThreadQueries().build();
            golfen_partien=golfen_db.golfen_spieler_dao().getAllGolfen_Partien().get(golfen_adapter.f);
            golf_spieler = golfen_partien.getGolfen_spieler();
            adapter.notifyDataSetChanged();
        }
    }
}

