package Database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;

/**
 * Created by NachtaktiverHalbaffe on 29.11.2017.
 */

@Database(entities = {Golfen_Partie.class}, version = 2, exportSchema = false)
@TypeConverters(DataConverter_Golfen.class)
public abstract class Golf_database extends RoomDatabase {
    public abstract Golfen_Partie_Dao golfen_spieler_dao();
}
