package Database;

import android.app.ProgressDialog;
import android.arch.persistence.room.Room;
import android.content.Context;
import android.os.AsyncTask;

import java.util.List;

public class Database_Builder extends AsyncTask<String,Void,List> {
    //Allgemeine Variabeln
    Context context;
    ProgressDialog progressDialog;
    private TaskCompleted mCallback;


    //Konstruktor
    public Database_Builder(Context context) {
        this.context = context;
    }

    //Hintergrund-Aufgabe
    @Override
    protected List doInBackground(String... strings) {

        if(strings.equals("Freizeiten")){
            return Room.databaseBuilder(context,Golf_database.class,"Golfen").fallbackToDestructiveMigration().build().golfen_spieler_dao().getAllGolfen_Partien();
        }
        else return null;
    }

    //Vor dem Schließen des Threads
    @Override
    protected void onPreExecute(){

    }

    //Nach dem Schließen des Threads
    @Override
    protected void onPostExecute(List result){
        mCallback.onTaskComplete(result);
        progressDialog.dismiss();
    }

    //Ladescreen
    @Override
    protected void onProgressUpdate(Void... values){
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Lädt Daten");
        progressDialog.setMax(10);
        progressDialog.setProgress(0);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
        //super.onProgressUpdate(values);
    }
    public interface TaskCompleted {
        // Define data you like to return from AysncTask
        public void onTaskComplete(List list);
    }
}

