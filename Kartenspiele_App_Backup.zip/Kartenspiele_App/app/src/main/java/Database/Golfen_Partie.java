package Database;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.TypeConverters;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import java.util.List;

@Entity(tableName = "Golfen_Partie")
public class Golfen_Partie {

    @NonNull
    @PrimaryKey(autoGenerate = false)
    private String partiebezeichnung;

    @TypeConverters(DataConverter_Golfen.class)
    @ColumnInfo(name = "Spieler")
    private List<Golfen_Spieler> golfen_spieler;

    public Golfen_Partie(String partiebezeichnung, List<Golfen_Spieler> golfen_spieler) {
        this.partiebezeichnung = partiebezeichnung;
        this.golfen_spieler = golfen_spieler;
    }

    public String getPartiebezeichnung() {
        return partiebezeichnung;
    }

    public void setPartiebezeichnung(String partiebezeichnung) {
        this.partiebezeichnung = partiebezeichnung;
    }

    public List<Golfen_Spieler> getGolfen_spieler() {
        return golfen_spieler;
    }

    public void setGolfen_spieler(List<Golfen_Spieler> golfen_spieler) {
        this.golfen_spieler = golfen_spieler;
    }
}
