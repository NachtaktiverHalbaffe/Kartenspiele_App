package Database;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface Golfen_Partie_Dao {
    @Query("SELECT * FROM Golfen_Partie")
    List <Golfen_Partie> getAllGolfen_Partien();

    //@Query("SELECT * FROM Golfen_Partie WHERE id = :id")
    //Golfen_Partie getGolfenPartieById(int id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addGolfen_Partie(Golfen_Partie golfen_partie);

    @Delete
    void deleteGolf_Partie(Golfen_Partie golfen_partie);

    @Update
    void updateGolfen_Partie(Golfen_Partie golfen_partie);
}
